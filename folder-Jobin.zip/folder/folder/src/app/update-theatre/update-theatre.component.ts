import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-update-theatre',
  templateUrl: './update-theatre.component.html',
  styleUrls: ['./update-theatre.component.css']
})
export class UpdateTheatreComponent implements OnInit {
  updateTheatreForm:FormGroup;
  
  errorMessage:String; 
  successMessage:String
  theatreName: String;
  location: String;
  seatingCapacity: String;
  rate: String;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit(){
    
    this.theatreName=sessionStorage.getItem("theatreName");
    this.location=sessionStorage.getItem("location");
    this.seatingCapacity=sessionStorage.getItem("seatingCapacity");
    this.rate=sessionStorage.getItem("rate");

    this.updateTheatreForm=this.formBuilder.group(
      {
        theatreName:[this.theatreName,Validators.required],
        location:[this.location,Validators.required],
        seatingCapacity:[this.seatingCapacity,Validators.required],
        rate:[this.rate,Validators.required]
      }
    )
  }

  updateTheatreFunction(){
    this.service.updateTheatre(this.updateTheatreForm.value).subscribe(response=>
      {
this.successMessage=response["Theatre"];
window.alert("successfully updated");
location.reload();
      },err=>
      {
this.errorMessage=err.error.message;
      })
  }

  back(){
    this.router.navigate(['/admin'])
  }

}
