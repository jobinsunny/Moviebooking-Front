import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { UsersComponent } from './users/users.component';
import { AdminComponent } from './admin/admin.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { DeleteMovieComponent } from './delete-movie/delete-movie.component';
import { UpdateMovieComponent } from './update-movie/update-movie.component';
import { AddTheatreComponent } from './add-theatre/add-theatre.component';
import { DeleteTheatreComponent } from './delete-theatre/delete-theatre.component';
import { UpdateTheatreComponent } from './update-theatre/update-theatre.component';
import { AddShowComponent } from './add-show/add-show.component';
import { DeleteShowComponent } from './delete-show/delete-show.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { BookingComponent } from './booking/booking.component';
import { CancelComponent } from './cancel/cancel.component';
import { MovieComponent } from './movie/movie.component';
import { TheatreComponent } from './theatre/theatre.component';
import { ShowComponent } from './show/show.component';
import { MoviedetailsComponent } from './moviedetails/moviedetails.component';
import { TheatredetailsComponent } from './theatredetails/theatredetails.component';
import { ShowsavlComponent } from './showsavl/showsavl.component';
import { FilterPipe } from './filter.pipe';
import { MyProfileComponent } from './my-profile/my-profile.component';

// import {ProductsModule} from './products/products.module'

@NgModule({
    imports: [BrowserModule, HttpClientModule, FormsModule, AppRoutingModule,ReactiveFormsModule],
    declarations: [AppComponent, WelcomeComponent, LoginComponent, WelcomepageComponent, LoginpageComponent, UsersComponent, AdminComponent, UsersignupComponent, AddMovieComponent, DeleteMovieComponent, UpdateMovieComponent, AddTheatreComponent, DeleteTheatreComponent, UpdateTheatreComponent, AddShowComponent, DeleteShowComponent, ViewBookingComponent, BookingComponent, CancelComponent, MovieComponent, TheatreComponent, ShowComponent, MoviedetailsComponent, TheatredetailsComponent, ShowsavlComponent, FilterPipe, MyProfileComponent],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
