import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-update-movie',
  templateUrl: './update-movie.component.html',
  styleUrls: ['./update-movie.component.css']
})
export class UpdateMovieComponent implements OnInit {
  
  updateMovieForm:FormGroup
  successMessage:String
  errorMessage:String
  movieName: String;
  director: String;
  genre: String;
  language: String;
  



  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.movieName=sessionStorage.getItem("movieName");
    this.director=sessionStorage.getItem("director");
    this.genre=sessionStorage.getItem("genre");
    this.language=sessionStorage.getItem("language");

    this.updateMovieForm=this.formBuilder.group(
      {
        movieName:[this.movieName,Validators.required],
        director:[this.director,Validators.required],
        genre:[this.genre,Validators.required],
        language:[this.language,Validators.required]
      }
    )
    
  }

  updateMovieFunction(){
    this.service.updateMovie(this.updateMovieForm.value).subscribe(response=>
      {
this.successMessage=response["Movie"];
window.alert("Successfully updated")
location.reload();
      },err=>
      {
this.errorMessage=err.error.message;
      })

  }

  back(){
    this.router.navigate(['/admin'])
  }

}
