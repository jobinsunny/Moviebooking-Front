import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { UsersComponent } from './users/users.component';
import { AdminComponent } from './admin/admin.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { AddTheatreComponent } from './add-theatre/add-theatre.component';
import { AddShowComponent } from './add-show/add-show.component';
import { DeleteMovieComponent } from './delete-movie/delete-movie.component';
import { DeleteTheatreComponent } from './delete-theatre/delete-theatre.component';
import { DeleteShowComponent } from './delete-show/delete-show.component';
import { BookingComponent } from './booking/booking.component';
import { CancelComponent } from './cancel/cancel.component';
import { MovieComponent } from './movie/movie.component';
import { TheatreComponent } from './theatre/theatre.component';
import { ShowComponent } from './show/show.component';
import { UpdateMovieComponent } from './update-movie/update-movie.component';
import { UpdateTheatreComponent } from './update-theatre/update-theatre.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { MoviedetailsComponent } from './moviedetails/moviedetails.component';
import { TheatredetailsComponent } from './theatredetails/theatredetails.component';
import { ShowsavlComponent } from './showsavl/showsavl.component';
import { MyProfileComponent } from './my-profile/my-profile.component';

// Routing configuration
const appRoutes: Routes = [
  { path: '', component: WelcomepageComponent },
  { path: 'loginpage', component: LoginpageComponent },
  {path:'usersignup',component: UsersignupComponent},
  {path:'users', component: UsersComponent},
  {path:'admin', component: AdminComponent},
  {path:'addMovie', component: AddMovieComponent},
  {path:'addTheatre', component: AddTheatreComponent},
  {path:'addShow', component: AddShowComponent},
  {path:'deleteMovie', component: DeleteMovieComponent},
  {path:'deleteTheatre', component: DeleteTheatreComponent},
  {path:'deleteShow', component: DeleteShowComponent},
  {path:'booking', component: BookingComponent},
  {path:'cancel', component: CancelComponent},
  {path:'movie', component: MovieComponent},
  {path:'theatre', component:TheatreComponent},
  {path:'show', component: ShowComponent},
  {path:'updateMovie', component: UpdateMovieComponent},
  {path:'updateTheatre', component: UpdateTheatreComponent},
  {path:'viewBooking',component: ViewBookingComponent},
  {path:'moviedetails',component:MoviedetailsComponent},
  {path:'theatredetails',component:TheatredetailsComponent},
  {path:'showsavl',component:ShowsavlComponent},
  {path:'myProfile',component:MyProfileComponent}

];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
