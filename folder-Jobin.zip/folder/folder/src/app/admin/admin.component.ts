import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit(): void {
  }

  back(){
    this.router.navigate(['/loginpage'])
  }

  movie(){
    this.router.navigate(['/movie'])
  }

  theatre(){
    this.router.navigate(['/theatre'])
  }

  show(){
    this.router.navigate(['/show'])
  }

  viewBooking(){
    this.router.navigate(['/viewBooking'])
  }  


}
