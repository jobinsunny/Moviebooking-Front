import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  loginForm:FormGroup;
  role:String;
  errorMessage:String;  

  got:String;


  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit()  {
    this.loginForm=this.formBuilder.group(
      {
        userName:['',Validators.required],
        password:['',Validators.required]
      }
    )

  }
  loginFunction(){
    this.errorMessage=null;
    localStorage.setItem("flag","true")
    this.service.login(this.loginForm.value).subscribe(response =>{
      this.got=response["User"];
      localStorage.setItem("userName",this.loginForm.value.userName);
      
        if(this.loginForm.value.userName=="admin"){
          this.router.navigate(['/admin'])
        }
        else{
          this.router.navigate(['/users'])
        }
      
    },err=>{
      this.errorMessage=err.error.message;
    });
   }

   back(){
    this.router.navigate([''])
   }

   
  }   


