import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  shows=[]
  errorMessage: String;
  successMessage: String;


  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    
    this.service.getShow().subscribe(book=>{
      this.shows=book;
    },err=>{
      this.errorMessage=err.message;
    })
  }

  back(){
    this.router.navigate(['/admin'])
  }

  delete(b){
    console.log(b.showId);
    this.service.deleteShow(b).subscribe(response=>
      {
this.successMessage=response["Show"];
window.alert("show deleted");
location.reload();
      },err=>{
this.errorMessage=err.error.message;
      })
  }

  addShow(){
    this.router.navigate(['/addShow'])
  }

}
