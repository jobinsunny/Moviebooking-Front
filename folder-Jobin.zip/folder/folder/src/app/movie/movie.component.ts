import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  movies=[]
  errorMessage:String;
  successMessage: String;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.service.getMovie().subscribe(book=>{
      this.movies=book;
    },err=>{
      this.errorMessage=err.message;
    })
  }


  back(){
    this.router.navigate(['/admin'])
  }

  delete(b){
    this.service.deleteMovie(b).subscribe(response=>
      {
this.successMessage=response["Movie"];
window.alert("Movie deleted");
location.reload();
      },err=>{
this.errorMessage=err.error.message;
window.alert("Show is already assigned for this movie.Cannot delete this movie.")
      })
  }

  update(b){
    sessionStorage.setItem("movieName",b.movieName)
    sessionStorage.setItem("director",b.director)
    sessionStorage.setItem("genre",b.genre)
    sessionStorage.setItem("language",b.language)
    this.router.navigate(['/updateMovie'])

  }

  addMovie(){
    this.router.navigate(['/addMovie'])
  }


}
