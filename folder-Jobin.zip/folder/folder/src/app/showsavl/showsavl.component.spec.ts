import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowsavlComponent } from './showsavl.component';

describe('ShowsavlComponent', () => {
  let component: ShowsavlComponent;
  let fixture: ComponentFixture<ShowsavlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowsavlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowsavlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
