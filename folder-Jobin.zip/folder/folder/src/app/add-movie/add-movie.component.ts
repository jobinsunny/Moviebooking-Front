import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  addMovieForm:FormGroup
  errorMessage:String;  
  got:String;
  successMessage:String

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.addMovieForm=this.formBuilder.group(
      {
        movieName:['',Validators.required],
        director:['',Validators.required],
        genre:['',Validators.required],
        language:['',Validators.required]

      }
    )
  }

  addMovieFunction(){
    this.errorMessage=null;
    this.successMessage=null;
    this.service.addMovie(this.addMovieForm.value).subscribe(response=>{
      this.successMessage=response["Movie"];
      window.alert("Successfully added");
      location.reload();
    },err=>{
      this.errorMessage=err.error.message;
 
    })

  }

  back(){
    this.router.navigate(['/admin'])
   }

}
