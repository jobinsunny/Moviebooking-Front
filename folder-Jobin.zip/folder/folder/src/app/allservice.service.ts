import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './model/User';
import { Observable } from 'rxjs';
import { Movie } from './model/Movie';
import { Theatre } from './model/Theatre';
import { Show } from './model/Show';
import { Booking } from './model/Booking';
import { Reports } from './model/Reports';

@Injectable({
  providedIn: 'root'
})
export class AllserviceService {
  private loginUrl="http://localhost:8079/user-service/userservice/authenticateUser"
  private addUserUrl="http://localhost:8079/user-service/userservice/addUser"
  private addMovieUrl="http://localhost:8079/movie-service/movieservice/addMovie"
  private addTheatreUrl="http://localhost:8079/theatre-service/theatreservice/addTheatre"
  private addShowUrl="http://localhost:8079/movie-service/movieservice/addShow"
  private bookingUrl="http://localhost:8079/booking-service/bookingservice/ticketBooking"
  private getReportUrl="http://localhost:8079/booking-service/bookingservice/getReport"
  private getMovieUrl="http://localhost:8079/movie-service/movieservice/getMovie"
  private getTheatreUrl="http://localhost:8079/theatre-service/theatreservice/getTheatre"
  private getShowUrl="http://localhost:8079/movie-service/movieservice/getShow"
  private updateMovieUrl="http://localhost:8079/movie-service/movieservice/updateMovie"
  private updateTheatreUrl="http://localhost:8079/theatre-service/theatreservice/updateTheatre"
  private deleteMovieUrl="http://localhost:8079/movie-service/movieservice/deleteMovie"
  private deleteTheatreUrl="http://localhost:8079/theatre-service/theatreservice/deleteTheatre"
  private deleteShowUrl="http://localhost:8079/movie-service/movieservice/deleteShow"
  private getBookingUrl="http://localhost:8079/booking-service/bookingservice/getBooking"
  private cancelBookingUrl="http://localhost:8079/booking-service/bookingservice/cancelBooking"

  constructor(private httpClient:HttpClient) { }

  login(data:User):Observable<User>{
    return this.httpClient.post<User>(this.loginUrl,data);
  }

  addUser(data:User):Observable<User>{
    return this.httpClient.post<User>(this.addUserUrl,data);
  }

  addMovie(data:Movie):Observable<Movie>{
    return this.httpClient.post<Movie>(this.addMovieUrl,data);
  }

  addTheatre(data:Theatre):Observable<Theatre>{
    return this.httpClient.post<Theatre>(this.addTheatreUrl,data);
  }

  addShow(data:Show):Observable<Show>{
    return this.httpClient.post<Show>(this.addShowUrl,data);
    
  }

  booking(data:Booking):Observable<Booking>{
    return this.httpClient.post<Booking>(this.bookingUrl,data);
  }

  getReport():Observable<Reports[]>{
    return this.httpClient.get<Reports[]>(this.getReportUrl);
  }

  getMovie():Observable<Movie[]>{
    return this.httpClient.get<Movie[]>(this.getMovieUrl);
  }

  getTheatre():Observable<Theatre[]>{
    return this.httpClient.get<Theatre[]>(this.getTheatreUrl);
  }

  getShow():Observable<Show[]>{
    return this.httpClient.get<Show[]>(this.getShowUrl);
  }

  updateMovie(data:Movie):Observable<Movie>{
    return this.httpClient.post<Movie>(this.updateMovieUrl,data);
  }  

  updateTheatre(data:Theatre):Observable<Theatre>{
    return this.httpClient.post<Theatre>(this.updateTheatreUrl,data);
  }

  deleteMovie(data:Movie):Observable<Movie>{
    return this.httpClient.post<Movie>(this.deleteMovieUrl,data);
  }

  deleteTheatre(data:Theatre):Observable<Theatre>{
    return this.httpClient.post<Theatre>(this.deleteTheatreUrl,data);
  }

  deleteShow(data:Movie):Observable<Movie>{
    return this.httpClient.post<Movie>(this.deleteShowUrl,data);
  }

  getBooking(data:Booking):Observable<Booking[]>{
    return this.httpClient.post<Booking[]>(this.getBookingUrl,data);
  }

  cancelBooking(data:Booking):Observable<Booking>{
    return this.httpClient.post<Booking>(this.cancelBookingUrl,data);
  }

}
