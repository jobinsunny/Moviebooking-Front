export class User{
    userName:string;
	password:string;
    role:string;
    emailId:string;
	phoneNumber:number;
}