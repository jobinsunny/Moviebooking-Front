export class Show{
    showId:number;
    movieName:string;
	theatreName:string;
    time:string;
    seatsAvailable:number;
	
}


