import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {
  signupForm:FormGroup;
  role:String;
  errorMessage:String; 
  successMessage:String
  
  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.signupForm=this.formBuilder.group(
      {
        userName:['',Validators.required],
        password:['',Validators.required],
        emailId:['',[Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
        phoneNumber:['',[Validators.required,Validators.maxLength(10),Validators.minLength(10)]]
      }
    )
  }
  signupFunction(){
    this.errorMessage=null;
    this.successMessage=null;
    this.service.addUser(this.signupForm.value).subscribe(response=>{
      this.successMessage=response["User"];
      window.alert("successfully registered");
      location.reload();
    },err=>{
      this.errorMessage=err.error.message;
      window.alert("user already exists");
 
    })
    
  }

  back(){
    this.router.navigate(['/'])
   }

}
