import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  bookingList=[]
  errorMessage: String;
  getbookings: FormGroup;
  successMessage: String;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.getbookings=this.formBuilder.group(
      {
        bookingId:[''],
        userName:[''],
        showTime:[''],
        showDate:[''],
        movieName:[''],
        theatreName:[''],
        seatsBooked:[''],
        totalPrice:['']
      }
    )
    this.getbookings.value.userName=localStorage.getItem("userName")
 
    this.service.getBooking(this.getbookings.value).subscribe(response =>{
            this.bookingList=response;
          },err=>{
            this.errorMessage=err.message;
    })
  }

  cancel(b){
    console.log(b);
    console.log(b.bookingId)
    this.service.cancelBooking(b).subscribe(response=>
      {
    this.successMessage=response["Booking"];
    window.alert("Booking cancelled");
    location.reload();
      },err=>{
    this.errorMessage=err.error.message;
      })
  }

  back(){

      this.router.navigate(['/users'])
  }

}
