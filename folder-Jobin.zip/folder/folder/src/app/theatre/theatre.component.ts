import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-theatre',
  templateUrl: './theatre.component.html',
  styleUrls: ['./theatre.component.css']
})
export class TheatreComponent implements OnInit {
  theatrelist=[];
  errorMessage: String;
  successMessage: String;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
      this.service.getTheatre().subscribe(response =>{
            this.theatrelist=response;
          },err=>{
            this.errorMessage=err.message;
    })
  }

  back(){
    this.router.navigate(['/admin'])
  }

  delete(b){
    this.service.deleteTheatre(b).subscribe(response=>
      {
        console.log("success portion")
this.successMessage=response["Theatre"];
window.alert("theatre deleted");
location.reload();
      },err=>{
        console.log("error portion")
this.errorMessage=err.error.message;
window.alert("Show is already assigned for this theatre.Cannot delete this theatre.")
      })
    
  }

  update(b){
    sessionStorage.setItem("theatreName",b.theatreName)
    sessionStorage.setItem("location",b.location)
    sessionStorage.setItem("seatingCapacity",b.seatingCapacity)
    sessionStorage.setItem("rate",b.rate)
    this.router.navigate(['/updateTheatre'])
  }

  addTheatre(){
    this.router.navigate(['/addTheatre'])
  }

}
