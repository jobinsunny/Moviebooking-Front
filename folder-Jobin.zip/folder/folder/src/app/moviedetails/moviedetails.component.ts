import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-moviedetails',
  templateUrl: './moviedetails.component.html',
  styleUrls: ['./moviedetails.component.css']
})
export class MoviedetailsComponent implements OnInit {
  movies=[]
  errorMessage: String;
  public searchText;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.service.getMovie().subscribe(book=>{
      this.movies=book;
    },err=>{
      this.errorMessage=err.message;
    })
  }

  back(){
    this.router.navigate(['/users'])
  }

}
