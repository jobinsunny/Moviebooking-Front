import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-show',
  templateUrl: './delete-show.component.html',
  styleUrls: ['./delete-show.component.css']
})
export class DeleteShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
